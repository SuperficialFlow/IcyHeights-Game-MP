﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Media;

namespace IcyHeights {
    class EndGame : EndPrompt {
        GameDesign gameDesign;
        GameOverObjects obj;
        public EndGame(GameDesign gameDesign, int score) {
            obj = new GameOverObjects(this, score);
            this.gameDesign = gameDesign;            
            GameOverScreen(score);
            CenterToScreen();
        }
        public void GameOverScreen(int score) {            
            this.Text = "Game Over";
            this.Width = 600;
            this.Height = 960;
            this.ControlBox = false;
            this.BackgroundImage = Image.FromFile(@"Resources\End.png");                        
            obj.tryAgain.Click += TryAgain;
            obj.exitButton.Click += ExitButton;            
        }
        public override void TryAgain(object sender, EventArgs e) {
            this.Close();
            gameDesign.ResetGame();
        }
        public override void ExitButton(object sender, EventArgs e) {
            gameDesign.ApplicationCLose();
            this.Close();
        }
    }

    class GameOverObjects {
        public Label scoreLabel;
        public Button tryAgain;
        public Button exitButton;
        SoundPlayer fail;
        EndGame endGame;
        public GameOverObjects(EndGame endGame, int score) {
            this.endGame = endGame;
            Score(score);
            TryAgain();
            Exit();
            SoundEnd();
        }
        public void Score(int score) {
            scoreLabel = new Label();            
            scoreLabel.Font = new Font("Arial", 24, FontStyle.Bold);
            scoreLabel.TextAlign = ContentAlignment.MiddleCenter;
            scoreLabel.Text = "Your Score: " + score;
            scoreLabel.Location = new Point(0, 400);
            scoreLabel.Size = new Size(600, 50);
            scoreLabel.BackColor = Color.Transparent;
            endGame.Controls.Add(scoreLabel);
        }
        public void TryAgain() {
            tryAgain = new Button();
            tryAgain.Text = "Try Again";
            tryAgain.Font = new Font("Arial", 18, FontStyle.Bold);
            tryAgain.Location = new Point(200, 500);
            tryAgain.Size = new Size(200, 50);
            tryAgain.BackColor = Color.Transparent;       
            endGame.Controls.Add(tryAgain);
        }
        public void Exit() {
            exitButton = new Button();
            exitButton.Text = "Exit";
            exitButton.Font = new Font("Arial", 18, FontStyle.Bold);
            exitButton.Location = new Point(200, 570);
            exitButton.Size = new Size(200, 50);
            exitButton.BackColor = Color.Transparent;
            endGame.Controls.Add(exitButton);
        }
        public void SoundEnd() {
            fail = new SoundPlayer(@"SFX\Fail.wav");
            fail.Play();
        }       
    }

    abstract class EndPrompt : Form {
        abstract public void TryAgain(object sender, EventArgs e);
        abstract public void ExitButton(object sender, EventArgs e);
    }
}