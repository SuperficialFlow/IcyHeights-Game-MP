﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Media;

namespace IcyHeights {
    class GameDesign : GameClass {
        EndGame gameOverForm;        
        Penguin pgn;
        Score sc;
        GameObjects btr;
        private int level = 1;
        private int bmovement = 10;
        public GameDesign(string user, int newScore) {
            sc = new Score(this);            
            btr = new GameObjects(this);
            pgn = new Penguin(this);
            sc.HighScore = newScore;            
            GameScreen();
            CenterToScreen();
        }
        public void GameScreen() {         
            this.DoubleBuffered = true;
            this.Text = "ICY HEIGHTS";
            this.Width = 600;
            this.Height = 960;
            this.ControlBox = false;
            this.BackgroundImage = Image.FromFile(@"Resources\Mountain.png");
            this.KeyDown += GameKeyDown;                                  
        }        
        public override void BoosterInstanceEvent(object sender, EventArgs e) {
            if (pgn.penguin.Bounds.IntersectsWith(btr.leftBorder.Bounds) ||
                pgn.penguin.Bounds.IntersectsWith(btr.rightBorder.Bounds) ||
                pgn.penguin.Bounds.IntersectsWith(btr.spikedBooster.Bounds)) {
                EndGame();
                return;
            }
            btr.booster1.Top += bmovement;
            btr.booster2.Top += bmovement;
            if ((btr.booster1.Top > this.Height) ||
                (btr.booster2.Top > this.Height)) {
                EndGame();
                return;
            }
            if (pgn.penguin.Bounds.IntersectsWith(btr.booster1.Bounds) ||
                pgn.penguin.Bounds.IntersectsWith(btr.booster2.Bounds)) {
                CheckCollision(btr.booster1);
                CheckCollision(btr.booster2);
            }
            btr.fakeBooster.Top += 15;
            if (btr.fakeBooster.Top > this.Height) {
                ChangeLocation(btr.fakeBooster);
            }
            btr.spikedBooster.Top += 10;
            if (btr.spikedBooster.Top > this.Height) {
                ChangeLocation(btr.spikedBooster);
            }
            if (sc.score >= level * 10) {
                level++;
                bmovement += 2;
                pgn.movement += 5;
            }
        }
        public override void CheckCollision(PictureBox booster) {
            if (pgn.penguin.Bounds.IntersectsWith(booster.Bounds)) {
                sc.score++;
                sc.scoreBox.Text = "Score: " + sc.score;
                sc.NewHighScore();
                ChangeLocation(booster);
            }
        }
        public override void ChangeLocation(PictureBox booster) {
            Random boosterPosition = new Random();
            int randomX = boosterPosition.Next(70, 450);
            booster.Location = new Point(randomX, -60);
        }
        public override void GameKeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left) {
                pgn.LeftControl();
            } else if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right) {
                pgn.RightControl();
            }
        }
        public int PlayerScore() {
            return sc.hiScore;
        }
        public override void ResetGame() {
            sc.score = 0;
            sc.scoreBox.Text = "Score: " + sc.score;
            pgn.penguin.Location = new Point(250, 700);
            btr.booster1.Location = new Point(260, 300);
            btr.booster2.Location = new Point(260, -60);
            btr.spikedBooster.Location = new Point(420, 100);
            btr.fakeBooster.Location = new Point(120, -220);
            btr.boosterTimer.Start();
            btr.tappy.PlayLooping();
            this.Show();
        }
        public override void EndGame() {
            btr.boosterTimer.Stop();
            gameOverForm = new EndGame(this, sc.score);
            this.Hide();
            gameOverForm.ShowDialog();
        }        
        public void ApplicationCLose() {
            this.Close();
        }
    }

    class Penguin {
        GameDesign gameDesign;
        public PictureBox penguin;
        public int movement = 20;
        public Penguin(GameDesign gameDesign) {
            this.gameDesign = gameDesign;
            CreatePenguin();
        }
        private void CreatePenguin() {
            penguin = new PictureBox();
            penguin.Image = Image.FromFile(@"Resources\Penguin.png");
            penguin.Location = new Point(250, 700);
            penguin.Size = new Size(90, 90);
            penguin.BackColor = Color.Transparent;
            gameDesign.Controls.Add(penguin);
        }
        public void LeftControl() {
            penguin.Left -= movement;
        }
        public void RightControl() {
            penguin.Left += movement;
        }
    }

    class Score {
        GameDesign gameDesign;
        public Label scoreBox;
        public Label hiScoreBox;
        public int score = 0;
        public int hiScore;
        public int HighScore {
            get { return hiScore; }
            set {                
                hiScore = value;
                UpdateHiScoreBox();
            }
        }
        public Score(GameDesign gameDesign) {
            this.gameDesign = gameDesign;            
            SetScore();
        }
        private void SetScore() {
            scoreBox = new Label();
            scoreBox.Text = "Score: " + score;
            scoreBox.Location = new Point(50, 10);
            scoreBox.Size = new Size(200, 20);
            scoreBox.ForeColor = Color.Black;
            scoreBox.BackColor = Color.Transparent;
            scoreBox.Font = new Font("Arial", 16, FontStyle.Bold);
            gameDesign.Controls.Add(scoreBox);

            hiScoreBox = new Label();
            hiScoreBox.Text = "High Score: " + hiScore;
            hiScoreBox.Location = new Point(50, 40);
            hiScoreBox.Size = new Size(200, 30);
            hiScoreBox.ForeColor = Color.Black;
            hiScoreBox.BackColor = Color.Transparent;
            hiScoreBox.Font = new Font("Arial", 16, FontStyle.Bold);
            gameDesign.Controls.Add(hiScoreBox);
        }
        public void NewHighScore() {
            if (score > hiScore) {
                HighScore = score;
            }
        }
        public void UpdateHiScoreBox() {
            hiScoreBox.Text = "High Score: " + hiScore;
        }        
    }

    class GameObjects {
        GameDesign gameDesign;
        public PictureBox booster1;
        public PictureBox booster2;
        public PictureBox fakeBooster;
        public PictureBox spikedBooster;
        public Timer boosterTimer;
        public SoundPlayer tappy;
        public PictureBox leftBorder;
        public PictureBox rightBorder;
        public GameObjects(GameDesign gameDesign) {
            this.gameDesign = gameDesign;
            CreateBooster();
            SoundObject();
            BorderObject();
            GameTimer();
        }
        public void CreateBooster() {
            booster1 = new PictureBox();
            booster1.Image = Image.FromFile(@"Resources\Booster.png");
            booster1.Location = new Point(260, 300);
            booster1.Size = new Size(70, 40);
            booster1.SizeMode = PictureBoxSizeMode.CenterImage;
            booster1.BackColor = Color.Transparent;
            gameDesign.Controls.Add(booster1);

            booster2 = new PictureBox();
            booster2.Image = new Bitmap(@"Resources\Booster.png");
            booster2.Location = new Point(260, -60);
            booster2.Size = new Size(70, 40);
            booster2.SizeMode = PictureBoxSizeMode.CenterImage;
            booster2.BackColor = Color.Transparent;
            gameDesign.Controls.Add(booster2);

            fakeBooster = new PictureBox();
            fakeBooster.Image = Image.FromFile(@"Resources\FakeBooster.png");
            fakeBooster.Location = new Point(120, -220);
            fakeBooster.Size = new Size(60, 40);
            fakeBooster.BackColor = Color.Transparent;
            gameDesign.Controls.Add(fakeBooster);

            spikedBooster = new PictureBox();
            spikedBooster.Image = Image.FromFile(@"Resources\SpikedBooster.png");
            spikedBooster.Location = new Point(420, 100);
            spikedBooster.Size = new Size(60, 40);
            spikedBooster.BackColor = Color.Transparent;
            gameDesign.Controls.Add(spikedBooster);
        }
        public void SoundObject() {
            tappy = new SoundPlayer(@"SFX\Tappy.wav");
            tappy.PlayLooping();
        }
        public void BorderObject() {
            leftBorder = new PictureBox();
            leftBorder.BackColor = Color.Gray;
            leftBorder.Size = new Size(40, 960);
            gameDesign.Controls.Add(leftBorder);

            rightBorder = new PictureBox();
            rightBorder.BackColor = Color.Gray;
            rightBorder.Size = new Size(40, 960);
            rightBorder.Location = new Point(550, 0);
            gameDesign.Controls.Add(rightBorder);
        }
        public void GameTimer() {
            boosterTimer = new Timer();
            boosterTimer.Tick += gameDesign.BoosterInstanceEvent;
            boosterTimer.Interval = 20;
            boosterTimer.Start();
        }
    }

    abstract class GameClass : Form {
        public abstract void BoosterInstanceEvent(object sender, EventArgs e);
        public abstract void CheckCollision(PictureBox booster);
        public abstract void ChangeLocation(PictureBox booster);
        public abstract void GameKeyDown(object sender, KeyEventArgs e);
        public abstract void ResetGame();
        public abstract void EndGame();
    }
}