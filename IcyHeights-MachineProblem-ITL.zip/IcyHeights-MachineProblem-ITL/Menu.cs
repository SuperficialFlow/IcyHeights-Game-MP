﻿using System.Windows.Forms;
using System.Drawing;
using System.Collections.Generic;
using System.IO;
using System;
using System.Linq;

namespace IcyHeights {
    internal class Menu : MenuPrompt {
        MenuInputs menuInp;
        public static List<string> txtFile = new List<string>();
        public static string fileName = @"Player\UserSaveData.txt";
        public Menu() {            
            if (!File.Exists(fileName)) {
                File.WriteAllText(fileName, string.Empty);
            }
            txtFile.Clear();
            txtFile = new List<string>(File.ReadAllLines(fileName));
            menuInp = new MenuInputs(this);
            MenuScreen();
        }

        public void MenuScreen() {             
            this.Text = "ICY HEIGHTS";
            this.Height = 500;
            this.Width = 700;
            this.MaximizeBox = false;
            this.BackgroundImage = Image.FromFile(@"Resources\Menu.png");
            CenterToScreen();
        }
    }

    class MenuInputs {
        Menu menu;
        Events events;
        public Button[] menuButtons = new Button[4];
        Panel newGamePanel;
        Panel loadGamePanel;
        Panel leaderboardPanel;
        public MenuInputs(Menu menu) {
            this.menu = menu;
            events = new Events(menu, this);
            MainScreen();
            ButtonEvents();  
        }
        public void MainScreen() {
            for (int i = 0; i < menuButtons.Length; i++) {
                menuButtons[i] = new Button();
                menuButtons[i].Size = new Size(100, 50);
                menuButtons[i].Location = new Point(290, 240 + i * 55);
                switch (i) {
                    case 0: menuButtons[i].Text = "New Game"; break;
                    case 1: menuButtons[i].Text = "Load Game"; break;
                    case 2: menuButtons[i].Text = "Leaderboard"; break;
                    case 3: menuButtons[i].Text = "Exit Game"; break;
                }
                menu.Controls.Add(menuButtons[i]);
            }
        }
        private void ButtonEvents() {
            events.ButtonEvents(menuButtons[1], events.Event2);
            events.ButtonEvents(menuButtons[0], events.Event1);
            events.ButtonEvents(menuButtons[2], events.Event3);
            events.ButtonEvents(menuButtons[3], events.Event4);
        }        
        public void NewGame() {
            newGamePanel = new Panel();
            newGamePanel.Size = new Size(300, 150);
            newGamePanel.Location = new Point(190, 150);
            newGamePanel.BackColor = Color.White;

            Label labelUser = new Label();
            labelUser.Text = "Enter Username:";
            labelUser.Location = new Point(30, 40);
            newGamePanel.Controls.Add(labelUser);

            TextBox inputBox = new TextBox();
            inputBox.Location = new Point(30, 70);
            inputBox.Width = 240;
            newGamePanel.Controls.Add(inputBox);

            Button confirmButton = new Button();
            confirmButton.Text = "Confirm";
            confirmButton.Location = new Point(70, 100);
            confirmButton.Click += ConfirmClick;
            newGamePanel.Controls.Add(confirmButton);

            Button cancelButton = new Button();
            cancelButton.Text = "Close";
            cancelButton.Location = new Point(160, 100);
            cancelButton.Click += CloseNG;                                    
            newGamePanel.Controls.Add(cancelButton);

            menu.Controls.Add(newGamePanel);
            newGamePanel.BringToFront();
        }        
        public void LoadGame() {
            if (Menu.txtFile.Count == 0) {
                MessageBox.Show("No Players Available");
                return;
            }
            loadGamePanel = new Panel();
            loadGamePanel.Size = new Size(180, 390);
            loadGamePanel.Location = new Point(250, 40);
            loadGamePanel.BackColor = Color.White;

            Label topTen = new Label();
            topTen.Font = new Font("Calibri", 15, FontStyle.Bold);
            topTen.AutoSize = true;
            topTen.Location = new Point(35, 15);
            topTen.Text = "Player Saves";
            loadGamePanel.Controls.Add(topTen);

            for (int i = 0; i < Menu.txtFile.Count; i++) {
                Button playerData = new Button();
                string[] user = Menu.txtFile[i].Split('|');
                string username = user[0];
                playerData.Text = $"{i + 1}. {username}";
                playerData.Tag = i;
                playerData.Click += OpenPlayer;
                playerData.Location = new Point(35, 45 + i * 30);
                loadGamePanel.Controls.Add(playerData);

                Button removePlayer = new Button();
                removePlayer.Text = "X";
                removePlayer.Width = 25;
                removePlayer.Tag = i; 
                removePlayer.Click += RemovePlayer;
                removePlayer.Location = new Point(115, 45 + i * 30);
                loadGamePanel.Controls.Add(removePlayer);
            }
            Button closeButton = new Button();
            closeButton.Text = "Close";
            closeButton.Click += CloseLG;
            closeButton.Location = new Point(50, 350);
            loadGamePanel.Controls.Add(closeButton);

            menu.Controls.Add(loadGamePanel);
            loadGamePanel.BringToFront();
        }        
        public void Leaderboard() {
            List<Player> leaderboardPlayers = new List<Player>();
            foreach (string line in Menu.txtFile) {
                string[] user = line.Split('|');
                string username = user[0];
                int score = int.Parse(user[1]);
                leaderboardPlayers.Add(new Player(username, score));
            }
            var sortedPlayers = leaderboardPlayers.OrderByDescending(p => p.Score).ToList();
            if (sortedPlayers.Count == 0) {
                MessageBox.Show("No Players Available");
                return;
            }
            leaderboardPanel = new Panel();
            leaderboardPanel.Size = new Size(180, 390);
            leaderboardPanel.Location = new Point(250, 40);
            leaderboardPanel.BackColor = Color.White;

            Label topTen = new Label();
            topTen.Font = new Font("Calibri", 15, FontStyle.Bold);
            topTen.AutoSize = true;
            topTen.Location = new Point(35, 15);
            topTen.Text = "Leaderboard";
            leaderboardPanel.Controls.Add(topTen);

            for (int i = 0; i < sortedPlayers.Count; i++) {
                Label playerTag = new Label();
                playerTag.Text = $"{i + 1}. {sortedPlayers[i].Username}: {sortedPlayers[i].Score}";
                playerTag.Tag = i;
                playerTag.Location = new Point(60, 45 + i * 30);
                leaderboardPanel.Controls.Add(playerTag);
            }
            Button closeButton = new Button();
            closeButton.Text = "Close";
            closeButton.Click += CloseBoard;
            closeButton.Location = new Point(50, 350);

            leaderboardPanel.Controls.Add(closeButton);
            menu.Controls.Add(leaderboardPanel);
            leaderboardPanel.BringToFront();
        }
        private void ConfirmClick(object sender, EventArgs e) {
            string username = ((TextBox)newGamePanel.Controls[1]).Text;
            if (string.IsNullOrEmpty(username) || username.Contains("|")) {
                MessageBox.Show("Invalid Input");
                return;
            } else if (Menu.txtFile.Count >= 10) {
                MessageBox.Show("Maximum Number of Players Reached.");
                return;
            }
            foreach (string line in Menu.txtFile) {
                string[] user = line.Split('|');
                if (user.Length == 2 && user[0] == username) {
                    MessageBox.Show("Player Already Exists");
                    return;
                }
            }
            menu.Hide();
            OpenGame.SaveData(username, 0);
            OpenGame.StartGame(username, 0);
            menu.Controls.Remove(newGamePanel);
            menu.Show();
        }
        private void CloseNG(object sender, EventArgs e) {
            menu.Controls.Remove(newGamePanel);
        }
        private void RemovePlayer(object sender, EventArgs e) {
            Button removeButton = (Button)sender;
            int index = (int)removeButton.Tag;
            if (index >= 0 && index < Menu.txtFile.Count) {
                Menu.txtFile.RemoveAt(index);
                File.WriteAllLines(Menu.fileName, Menu.txtFile);
                menu.Controls.Remove(loadGamePanel);
                LoadGame();
            }
        }
        private void OpenPlayer(object sender, EventArgs e) {
            Button playerButton = (Button)sender;
            int index = (int)playerButton.Tag;
            string[] user = Menu.txtFile[index].Split('|');            
            menu.Hide();            
            OpenGame.SaveData(user[0], int.Parse(user[1]));
            OpenGame.StartGame(user[0], int.Parse(user[1]));            
            menu.Show();
        }
        private void CloseLG(object sender, EventArgs e) {
            menu.Controls.Remove(loadGamePanel);
        }
        private void CloseBoard(object sender, EventArgs e) {
            menu.Controls.Remove(leaderboardPanel);
        }
    }

    class Events {
        Menu menu;
        MenuInputs menuInp;
        public Events(Menu menu, MenuInputs menuInp) { 
            this.menu = menu;
            this.menuInp = menuInp;
        }
        public void ButtonEvents(Button button, EventHandler choice) {
            button.Click += choice;
        }
        public void Event1(object sender, EventArgs e) {
            menuInp.NewGame();
        }
        public void Event2(object sender, EventArgs e) {
            menuInp.LoadGame();
        }
        public void Event3(object sender, EventArgs e) {
            menuInp.Leaderboard();
        }
        public void Event4(object sender, EventArgs e) {
            menu.Close();
        }
    }

    class Player {
        public string Username { get; }
        public int Score { get; set; }
        public Player(string username) {
            Username = username;
            Score = 0;
        }
        public Player(string username, int score) {
            Username = username;
            Score = score;
        }
    }

    class OpenGame {
        private static List<Player> players = new List<Player>();
        public static void StartGame(string username, int score) {
            Player player = null;
            foreach (Player p in players) {
                if (p.Username == username) {
                    player = p;
                    break;
                }
            }
            if (player == null) {
                player = new Player(username);
                players.Add(player);
            }
            GameDesign gameUI = new GameDesign(username, score);
            Score sc = new Score(gameUI);
            gameUI.ShowDialog();
            int gameScore = gameUI.PlayerScore();
            player.Score = gameScore;
            SaveData(username, player.Score);
            Console.Clear();
        }
        public static void SaveData(string username, int score) {            
            bool found = false;
            for (int i = 0; i < Menu.txtFile.Count; i++) {
                string[] parts = Menu.txtFile[i].Split('|');
                if (parts.Length == 2 && parts[0] == username) {
                    Menu.txtFile[i] = $"{username}|{score}";
                    found = true;
                    break;
                }
            }
            if (!found) {
                Menu.txtFile.Add($"{username}|{score}");
            }
            File.WriteAllLines(Menu.fileName, Menu.txtFile);
        }
    }
    abstract class MenuPrompt : Form {
    }
}
