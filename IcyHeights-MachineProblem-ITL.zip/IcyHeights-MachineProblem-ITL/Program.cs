﻿using System.Windows.Forms;
namespace IcyHeights {
    public class Program {
        static void Main(string[] args) {
            Menu menu = new Menu();
            Application.Run(menu);
        }
    }
}